@echo off
set APP_HOME=%~dp0
set JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar
if not exist "%JAR%" (
  pushd "%APP_HOME%"
  java gradle\wrapper\WrapperDownloader.java
  if errorlevel 1 exit /b 1
  popd
)
java -Dorg.gradle.appname=gradlew -classpath "%JAR%" org.gradle.wrapper.GradleWrapperMain %*
