import java.io.InputStream;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.util.HexFormat;

public class WrapperDownloader {
    private static final String EXPECTED_SHA256 =
            "81a82aaea5abcc8ff68b3dfcb58b3c3c429378efd98e7433460610fecd7ae45f";

    public static void main(String[] args) throws Exception {
        Path target = Path.of("gradle", "wrapper", "gradle-wrapper.jar");
        Path temporary = target.resolveSibling("gradle-wrapper.jar.download");
        Files.createDirectories(target.getParent());

        URI source = URI.create(
                "https://raw.githubusercontent.com/gradle/gradle/v8.13.0/gradle/wrapper/gradle-wrapper.jar"
        );

        System.out.println("Downloading Gradle wrapper 8.13...");
        try (InputStream in = source.toURL().openStream()) {
            Files.copy(in, temporary, StandardCopyOption.REPLACE_EXISTING);
        }

        String actualSha256 = sha256(temporary);
        if (!EXPECTED_SHA256.equalsIgnoreCase(actualSha256)) {
            Files.deleteIfExists(temporary);
            throw new SecurityException(
                    "Gradle wrapper checksum mismatch. Expected " + EXPECTED_SHA256
                            + " but received " + actualSha256
            );
        }

        Files.move(temporary, target, StandardCopyOption.REPLACE_EXISTING);
        System.out.println("Gradle wrapper verified and ready.");
    }

    private static String sha256(Path file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream in = Files.newInputStream(file)) {
            byte[] buffer = new byte[8192];
            int read;
            while ((read = in.read(buffer)) != -1) {
                digest.update(buffer, 0, read);
            }
        }
        return HexFormat.of().formatHex(digest.digest());
    }
}
