package ir.havashenasi6.app.data.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import ir.havashenasi6.app.domain.AppSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.settingsDataStore by preferencesDataStore(name = "havashenasi6_settings")

class SettingsRepository(private val context: Context) {
    private object Keys {
        val locationName = stringPreferencesKey("location_name")
        val latitude = doublePreferencesKey("latitude")
        val longitude = doublePreferencesKey("longitude")
        val autoLocation = booleanPreferencesKey("auto_location")
        val useFahrenheit = booleanPreferencesKey("use_fahrenheit")
        val useMiles = booleanPreferencesKey("use_miles")
        val darkTheme = booleanPreferencesKey("dark_theme")
    }

    val settings: Flow<AppSettings> = context.settingsDataStore.data
        .catch { error ->
            if (error is IOException) emit(emptyPreferences()) else throw error
        }
        .map { prefs ->
            AppSettings(
                locationName = prefs[Keys.locationName] ?: "موقعیت اصلی",
                latitude = prefs[Keys.latitude] ?: 37.189189,
                longitude = prefs[Keys.longitude] ?: 55.548342,
                autoLocation = prefs[Keys.autoLocation] ?: false,
                useFahrenheit = prefs[Keys.useFahrenheit] ?: false,
                useMiles = prefs[Keys.useMiles] ?: false,
                darkTheme = prefs[Keys.darkTheme] ?: true
            )
        }

    suspend fun saveLocation(name: String, latitude: Double, longitude: Double) {
        context.settingsDataStore.edit { prefs ->
            prefs[Keys.locationName] = name.ifBlank { "موقعیت اصلی" }
            prefs[Keys.latitude] = latitude
            prefs[Keys.longitude] = longitude
        }
    }

    suspend fun setAutoLocation(enabled: Boolean) {
        context.settingsDataStore.edit { it[Keys.autoLocation] = enabled }
    }

    suspend fun setUseFahrenheit(enabled: Boolean) {
        context.settingsDataStore.edit { it[Keys.useFahrenheit] = enabled }
    }

    suspend fun setUseMiles(enabled: Boolean) {
        context.settingsDataStore.edit { it[Keys.useMiles] = enabled }
    }

    suspend fun setDarkTheme(enabled: Boolean) {
        context.settingsDataStore.edit { it[Keys.darkTheme] = enabled }
    }
}
