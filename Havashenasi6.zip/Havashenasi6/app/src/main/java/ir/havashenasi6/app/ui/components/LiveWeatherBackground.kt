package ir.havashenasi6.app.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import ir.havashenasi6.app.domain.WeatherKind
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun LiveWeatherBackground(
    kind: WeatherKind,
    isDay: Boolean,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val palette = paletteFor(kind, isDay)
    val top by animateColorAsState(palette.first, tween(1200), label = "topColor")
    val middle by animateColorAsState(palette.second, tween(1200), label = "middleColor")
    val bottom by animateColorAsState(palette.third, tween(1200), label = "bottomColor")

    val infinite = rememberInfiniteTransition(label = "weatherMotion")
    val cloudProgress by infinite.animateFloat(
        initialValue = -0.12f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(tween(22000, easing = LinearEasing), RepeatMode.Restart),
        label = "cloudProgress"
    )
    val drops by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Restart),
        label = "drops"
    )
    val pulse by infinite.animateFloat(
        initialValue = 0.86f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800), RepeatMode.Reverse),
        label = "sunPulse"
    )
    val flash by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2300), RepeatMode.Restart),
        label = "flash"
    )

    Box(
        modifier = modifier.background(Brush.verticalGradient(listOf(top, middle, bottom)))
    ) {
        Canvas(Modifier.matchParentSize()) {
            if (isDay && kind in listOf(WeatherKind.SUNNY, WeatherKind.MOSTLY_CLEAR)) {
                drawSun(Offset(size.width * .80f, size.height * .15f), size.minDimension * .10f * pulse)
            }
            if (kind != WeatherKind.SUNNY) {
                drawCloud(size.width * cloudProgress, size.height * .18f, size.minDimension * .11f, .34f)
                drawCloud(size.width * ((cloudProgress + .46f) % 1.24f), size.height * .31f, size.minDimension * .15f, .23f)
            }
            when (kind) {
                WeatherKind.DRIZZLE, WeatherKind.RAIN, WeatherKind.HEAVY_RAIN, WeatherKind.STORM -> drawRain(drops, kind == WeatherKind.HEAVY_RAIN || kind == WeatherKind.STORM)
                WeatherKind.SNOW -> drawSnow(drops)
                WeatherKind.FOG -> drawFog(cloudProgress)
                WeatherKind.WINDY -> drawWind(cloudProgress)
                else -> Unit
            }
            if (kind == WeatherKind.STORM && flash > .91f) {
                drawRect(Color.White.copy(alpha = ((flash - .91f) * 3f).coerceAtMost(.22f)))
                drawLightning()
            }
        }
        content()
    }
}

private fun paletteFor(kind: WeatherKind, isDay: Boolean): Triple<Color, Color, Color> {
    if (!isDay) return when (kind) {
        WeatherKind.STORM -> Triple(Color(0xFF090A20), Color(0xFF17152D), Color(0xFF101F36))
        WeatherKind.RAIN, WeatherKind.HEAVY_RAIN, WeatherKind.DRIZZLE -> Triple(Color(0xFF071827), Color(0xFF123552), Color(0xFF1B5572))
        WeatherKind.CLOUDY, WeatherKind.FOG -> Triple(Color(0xFF101827), Color(0xFF26384E), Color(0xFF42566B))
        else -> Triple(Color(0xFF061226), Color(0xFF0C2F55), Color(0xFF174D75))
    }
    return when (kind) {
        WeatherKind.SUNNY -> Triple(Color(0xFF1479C9), Color(0xFF31A8E1), Color(0xFF9BDBF1))
        WeatherKind.MOSTLY_CLEAR -> Triple(Color(0xFF176EA9), Color(0xFF4AA5CE), Color(0xFFA5D6E8))
        WeatherKind.CLOUDY, WeatherKind.FOG -> Triple(Color(0xFF526B7D), Color(0xFF7893A3), Color(0xFFB7CBD3))
        WeatherKind.DRIZZLE, WeatherKind.RAIN -> Triple(Color(0xFF244E70), Color(0xFF3B718E), Color(0xFF77AABC))
        WeatherKind.HEAVY_RAIN, WeatherKind.STORM -> Triple(Color(0xFF172B45), Color(0xFF314B63), Color(0xFF617988))
        WeatherKind.SNOW -> Triple(Color(0xFF527C9A), Color(0xFF91B9CC), Color(0xFFD9EBF1))
        WeatherKind.WINDY -> Triple(Color(0xFF2A6F8E), Color(0xFF5AA5B9), Color(0xFFB1DBDE))
    }
}

private fun DrawScope.drawSun(center: Offset, radius: Float) {
    val sun = Color(0xFFFFD15C)
    drawCircle(sun.copy(alpha = .18f), radius * 1.65f, center)
    drawCircle(sun, radius, center)
    repeat(12) { i ->
        val angle = i * (2f * PI.toFloat() / 12f)
        val from = Offset(center.x + cos(angle) * radius * 1.25f, center.y + sin(angle) * radius * 1.25f)
        val to = Offset(center.x + cos(angle) * radius * 1.60f, center.y + sin(angle) * radius * 1.60f)
        drawLine(sun.copy(alpha = .75f), from, to, radius * .10f, cap = StrokeCap.Round)
    }
}

private fun DrawScope.drawCloud(x: Float, y: Float, r: Float, alpha: Float) {
    val cloud = Color.White.copy(alpha = alpha)
    drawCircle(cloud, r * .72f, Offset(x, y))
    drawCircle(cloud, r, Offset(x + r * .80f, y - r * .18f))
    drawCircle(cloud, r * .72f, Offset(x + r * 1.55f, y))
    drawRoundRect(cloud, Offset(x - r * .65f, y), Size(r * 2.9f, r * .85f))
}

private fun DrawScope.drawRain(progress: Float, heavy: Boolean) {
    val count = if (heavy) 38 else 22
    repeat(count) { i ->
        val x = ((i * 73) % 101) / 100f * size.width
        val phase = (progress + i * .071f) % 1f
        val y = size.height * (.28f + phase * .75f)
        drawLine(Color(0xFFA2E6FF).copy(alpha = .45f), Offset(x, y), Offset(x - 8f, y + 28f), if (heavy) 3.2f else 2.3f, cap = StrokeCap.Round)
    }
}

private fun DrawScope.drawSnow(progress: Float) {
    repeat(30) { i ->
        val phase = (progress * (.55f + (i % 4) * .12f) + i * .09f) % 1f
        val x = (((i * 47) % 100) / 100f * size.width) + sin(phase * PI.toFloat() * 2f) * 18f
        val y = size.height * (.18f + phase * .86f)
        drawCircle(Color.White.copy(alpha = .62f), 2.5f + (i % 3), Offset(x, y))
    }
}

private fun DrawScope.drawFog(progress: Float) {
    repeat(7) { i ->
        val y = size.height * (.30f + i * .08f)
        val shift = (progress * size.width * .15f * if (i % 2 == 0) 1 else -1)
        drawLine(Color.White.copy(alpha = .13f), Offset(-size.width * .1f + shift, y), Offset(size.width * 1.1f + shift, y), 18f, cap = StrokeCap.Round)
    }
}

private fun DrawScope.drawWind(progress: Float) {
    repeat(6) { i ->
        val y = size.height * (.25f + i * .11f)
        val left = ((progress + i * .13f) % 1f) * size.width
        drawArc(Color.White.copy(alpha = .18f), -15f, 190f, false, Offset(left - 180f, y), Size(260f, 70f), style = Stroke(5f, cap = StrokeCap.Round))
    }
}

private fun DrawScope.drawLightning() {
    val x = size.width * .58f
    val y = size.height * .19f
    val path = androidx.compose.ui.graphics.Path().apply {
        moveTo(x, y)
        lineTo(x - 34f, y + 110f)
        lineTo(x + 8f, y + 98f)
        lineTo(x - 18f, y + 205f)
        lineTo(x + 65f, y + 72f)
        lineTo(x + 18f, y + 84f)
        close()
    }
    drawPath(path, Color(0xFFFFEE8A).copy(alpha = .72f))
}
