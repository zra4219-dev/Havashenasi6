package ir.havashenasi6.app.ui.screens

import ir.havashenasi6.app.domain.AppSettings
import ir.havashenasi6.app.util.oneDecimalFa
import ir.havashenasi6.app.util.roundFa

fun temperatureText(celsius: Double, settings: AppSettings, decimal: Boolean = false): String {
    val value = if (settings.useFahrenheit) celsius * 9.0 / 5.0 + 32.0 else celsius
    val number = if (decimal) value.oneDecimalFa() else value.roundFa()
    return "$number°"
}

fun windText(kmh: Double, settings: AppSettings): String {
    val value = if (settings.useMiles) kmh * 0.621371 else kmh
    return "${value.oneDecimalFa()} ${if (settings.useMiles) "مایل/س" else "کم/س"}"
}

fun windDirectionFa(degree: Int): String {
    val directions = listOf("شمال", "شمال‌شرق", "شرق", "جنوب‌شرق", "جنوب", "جنوب‌غرب", "غرب", "شمال‌غرب")
    return directions[((degree + 22) / 45) % 8]
}

fun aqiLabel(aqi: Int): String = when {
    aqi <= 20 -> "عالی"
    aqi <= 40 -> "خوب"
    aqi <= 60 -> "متوسط"
    aqi <= 80 -> "ناسالم برای حساس‌ها"
    aqi <= 100 -> "ناسالم"
    else -> "بسیار ناسالم"
}
