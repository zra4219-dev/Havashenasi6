package ir.havashenasi6.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ir.havashenasi6.app.MainUiState
import ir.havashenasi6.app.ui.components.GlassCard
import ir.havashenasi6.app.ui.components.LiveWeatherBackground
import ir.havashenasi6.app.ui.components.WeatherIcon
import ir.havashenasi6.app.ui.components.WeatherSkeleton
import ir.havashenasi6.app.util.PersianDateFormatter
import ir.havashenasi6.app.util.fa
import ir.havashenasi6.app.util.oneDecimalFa
import ir.havashenasi6.app.util.roundFa

@Composable
fun HomeScreen(
    state: MainUiState,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier
) {
    val weather = state.weather
    val kind = weather?.current?.kind ?: ir.havashenasi6.app.domain.WeatherKind.MOSTLY_CLEAR
    val isDay = weather?.current?.isDay ?: true

    LiveWeatherBackground(kind = kind, isDay = isDay, modifier = modifier.fillMaxSize()) {
        if (state.isLoading && weather == null) {
            WeatherSkeleton(Modifier.fillMaxSize())
            return@LiveWeatherBackground
        }

        if (weather == null) {
            Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                GlassCard {
                    Text("داده‌ای برای نمایش وجود ندارد.", style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(8.dp))
                    Text(state.errorMessage ?: "اتصال اینترنت را بررسی کنید.")
                    IconButton(onClick = onRefresh) { Icon(Icons.Rounded.Refresh, null) }
                }
            }
            return@LiveWeatherBackground
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("هواشناسی ۶", style = MaterialTheme.typography.titleLarge, color = Color.White)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.LocationOn, null, Modifier.size(16.dp), tint = Color.White.copy(.82f))
                        Spacer(Modifier.width(4.dp))
                        Text(state.settings.locationName, color = Color.White.copy(.88f))
                    }
                }
                if (state.isRefreshing) {
                    CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp, color = Color.White)
                } else {
                    IconButton(onClick = onRefresh) { Icon(Icons.Rounded.Refresh, "به‌روزرسانی", tint = Color.White) }
                }
            }

            if (weather.fromCache) {
                GlassCard(contentPadding = androidx.compose.foundation.layout.PaddingValues(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.CloudOff, null, Modifier.size(18.dp), tint = Color(0xFFFFE49A))
                        Spacer(Modifier.width(8.dp))
                        Text("حالت آفلاین؛ آخرین داده ذخیره‌شده نمایش داده می‌شود.", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                WeatherIcon(weather.current.kind, Modifier.size(118.dp))
                Text(
                    temperatureText(weather.current.temperature, state.settings),
                    style = MaterialTheme.typography.displayLarge,
                    color = Color.White
                )
                Text(weather.current.kind.faTitle, style = MaterialTheme.typography.headlineLarge, color = Color.White)
                Text(
                    PersianDateFormatter.dateLabel(weather.current.time),
                    color = Color.White.copy(.82f)
                )
                Text(
                    "احساس واقعی ${temperatureText(weather.current.apparentTemperature, state.settings)}",
                    color = Color.White.copy(.88f)
                )
            }

            GlassCard(Modifier.fillMaxWidth()) {
                Text("جزئیات لحظه‌ای", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MiniStat("رطوبت", "${weather.current.humidity.fa()}٪", Modifier.weight(1f))
                    MiniStat("باد", windText(weather.current.windSpeed, state.settings), Modifier.weight(1f))
                    MiniStat("جهت", windDirectionFa(weather.current.windDirection), Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MiniStat("فشار", "${weather.current.pressure.roundFa()} hPa", Modifier.weight(1f))
                    MiniStat("دید", "${(weather.current.visibility / 1000.0).oneDecimalFa()} کیلومتر", Modifier.weight(1f))
                    MiniStat("UV", weather.hourly.firstOrNull()?.uvIndex?.oneDecimalFa() ?: "—", Modifier.weight(1f))
                }
            }

            GlassCard(Modifier.fillMaxWidth()) {
                Text("۴۸ ساعت آینده", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(12.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(weather.hourly.take(48)) { item ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(72.dp)) {
                            Text(PersianDateFormatter.hour(item.time), color = Color.White.copy(.78f))
                            WeatherIcon(item.kind, Modifier.size(44.dp).padding(4.dp))
                            Text(temperatureText(item.temperature, state.settings), fontWeight = FontWeight.Bold)
                            Text("${item.precipitationProbability.fa()}٪", style = MaterialTheme.typography.bodyMedium, color = Color(0xFFBEEBFF))
                        }
                    }
                }
            }

            weather.airQuality?.let { air ->
                GlassCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("کیفیت هوا", style = MaterialTheme.typography.titleLarge)
                            Text(aqiLabel(air.europeanAqi), color = Color.White.copy(.82f))
                        }
                        Text(air.europeanAqi.fa(), style = MaterialTheme.typography.headlineLarge, color = Color(0xFFFFE08A))
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("PM2.5: ${air.pm25.oneDecimalFa()}   •   PM10: ${air.pm10.oneDecimalFa()}")
                }
            }

            GlassCard(Modifier.fillMaxWidth()) {
                Text("پیش‌بینی ۱۰ روزه", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(6.dp))
                weather.daily.take(6).forEachIndexed { index, day ->
                    if (index > 0) HorizontalDivider(color = Color.White.copy(.12f))
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(PersianDateFormatter.shortDate(day.date), Modifier.width(58.dp), color = Color.White.copy(.82f))
                        WeatherIcon(day.kind, Modifier.size(42.dp).padding(5.dp))
                        Text(day.kind.faTitle, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        Text("${temperatureText(day.temperatureMax, state.settings)} / ${temperatureText(day.temperatureMin, state.settings)}", fontWeight = FontWeight.Bold)
                    }
                }
            }

            state.errorMessage?.let {
                Text(it, color = Color(0xFFFFD0C8), modifier = Modifier.padding(8.dp))
            }
            Spacer(Modifier.height(90.dp))
        }
    }
}

@Composable
private fun MiniStat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(.70f))
        Text(value, fontWeight = FontWeight.Bold, color = Color.White)
    }
}
