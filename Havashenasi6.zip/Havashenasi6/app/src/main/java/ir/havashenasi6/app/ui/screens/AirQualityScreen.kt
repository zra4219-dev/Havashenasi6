package ir.havashenasi6.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ir.havashenasi6.app.MainUiState
import ir.havashenasi6.app.ui.components.GlassCard
import ir.havashenasi6.app.ui.components.LiveWeatherBackground
import ir.havashenasi6.app.util.fa
import ir.havashenasi6.app.util.oneDecimalFa

@Composable
fun AirQualityScreen(state: MainUiState, modifier: Modifier = Modifier) {
    val weather = state.weather
    val air = weather?.airQuality
    LiveWeatherBackground(
        kind = weather?.current?.kind ?: ir.havashenasi6.app.domain.WeatherKind.FOG,
        isDay = weather?.current?.isDay ?: true,
        modifier = modifier.fillMaxSize()
    ) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("آلودگی هوا", style = MaterialTheme.typography.headlineLarge, color = Color.White)
            Text(state.settings.locationName, color = Color.White.copy(.8f))

            if (air == null) {
                GlassCard(Modifier.fillMaxWidth()) {
                    Text("اطلاعات کیفیت هوا در دسترس نیست.")
                    Text("با اتصال اینترنت و به‌روزرسانی مجدد تلاش کنید.", color = Color.White.copy(.7f))
                }
            } else {
                GlassCard(Modifier.fillMaxWidth()) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        AqiGauge(air.europeanAqi, Modifier.fillMaxWidth().height(190.dp))
                        Text(air.europeanAqi.fa(), style = MaterialTheme.typography.headlineLarge, color = Color.White)
                        Text(aqiLabel(air.europeanAqi), style = MaterialTheme.typography.titleLarge, color = Color(0xFFFFE08A))
                    }
                }

                GlassCard(Modifier.fillMaxWidth()) {
                    Text("جزئیات آلاینده‌ها", style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(12.dp))
                    PollutantRow("ذرات ریز PM2.5", air.pm25, "µg/m³")
                    PollutantRow("ذرات PM10", air.pm10, "µg/m³")
                    PollutantRow("مونوکسید کربن", air.carbonMonoxide, "µg/m³")
                    PollutantRow("دی‌اکسید نیتروژن", air.nitrogenDioxide, "µg/m³")
                    PollutantRow("ازن", air.ozone, "µg/m³")
                }

                GlassCard(Modifier.fillMaxWidth()) {
                    Text("راهنمای سلامت", style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        when {
                            air.europeanAqi <= 40 -> "کیفیت هوا مناسب است و فعالیت معمول در فضای باز محدودیتی ندارد."
                            air.europeanAqi <= 80 -> "افراد حساس بهتر است فعالیت طولانی و سنگین در فضای باز را کاهش دهند."
                            else -> "فعالیت غیرضروری در فضای باز را کم کنید و کودکان، سالمندان و بیماران قلبی‌ـ‌ریوی بیشتر احتیاط کنند."
                        },
                        color = Color.White.copy(.82f)
                    )
                }
            }
            Spacer(Modifier.height(90.dp))
        }
    }
}

@Composable
private fun AqiGauge(aqi: Int, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val stroke = 22f
        val pad = 30f
        val arcSize = Size(size.width - pad * 2, size.height * 1.55f)
        val topLeft = Offset(pad, size.height * .18f)
        val segments = listOf(
            Color(0xFF6FD08C), Color(0xFFE9D66B), Color(0xFFF3A75B),
            Color(0xFFE76F6F), Color(0xFF9B6DC6)
        )
        segments.forEachIndexed { i, color ->
            drawArc(
                color = color.copy(alpha = .92f),
                startAngle = 180f + i * 36f,
                sweepAngle = 34f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(stroke, cap = StrokeCap.Round)
            )
        }
        val clamped = aqi.coerceIn(0, 120)
        val angle = Math.toRadians((180 + clamped / 120f * 180f).toDouble())
        val center = Offset(size.width / 2, topLeft.y + arcSize.height / 2)
        val radiusX = arcSize.width / 2 - 14f
        val radiusY = arcSize.height / 2 - 14f
        val end = Offset(
            center.x + kotlin.math.cos(angle).toFloat() * radiusX,
            center.y + kotlin.math.sin(angle).toFloat() * radiusY
        )
        drawLine(Color.White, center, end, 8f, cap = StrokeCap.Round)
        drawCircle(Color.White, 12f, center)
    }
}

@Composable
private fun PollutantRow(title: String, value: Double, unit: String) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title, color = Color.White.copy(.78f))
        Text("${value.oneDecimalFa()} $unit", fontWeight = FontWeight.Bold)
    }
}
