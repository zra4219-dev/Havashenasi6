package ir.havashenasi6.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "weather_cache")
data class WeatherCacheEntity(
    @PrimaryKey val locationKey: String,
    val latitude: Double,
    val longitude: Double,
    val forecastJson: String,
    val airQualityJson: String?,
    val fetchedAt: Long
)
