package ir.havashenasi6.app.data.repository

import com.google.gson.Gson
import ir.havashenasi6.app.data.local.WeatherCacheDao
import ir.havashenasi6.app.data.local.WeatherCacheEntity
import ir.havashenasi6.app.data.remote.AirQualityResponse
import ir.havashenasi6.app.data.remote.ForecastResponse
import ir.havashenasi6.app.data.remote.OpenMeteoApi
import ir.havashenasi6.app.domain.AirQuality
import ir.havashenasi6.app.domain.CurrentWeather
import ir.havashenasi6.app.domain.DailyForecast
import ir.havashenasi6.app.domain.HourlyForecast
import ir.havashenasi6.app.domain.WeatherBundle
import ir.havashenasi6.app.util.WeatherCodeMapper
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.supervisorScope
import java.util.Locale

class WeatherRepository(
    private val api: OpenMeteoApi,
    private val cacheDao: WeatherCacheDao,
    private val gson: Gson
) {
    suspend fun loadWeather(latitude: Double, longitude: Double): WeatherBundle = supervisorScope {
        val forecastDeferred = async { api.getForecast(forecastUrl(latitude, longitude)) }
        val airDeferred = async {
            try {
                api.getAirQuality(airQualityUrl(latitude, longitude))
            } catch (error: CancellationException) {
                throw error
            } catch (_: Throwable) {
                null
            }
        }

        try {
            val forecast = forecastDeferred.await()
            val air = airDeferred.await()
            val now = System.currentTimeMillis()
            cacheDao.upsert(
                WeatherCacheEntity(
                    locationKey = locationKey(latitude, longitude),
                    latitude = latitude,
                    longitude = longitude,
                    forecastJson = gson.toJson(forecast),
                    airQualityJson = air?.let(gson::toJson),
                    fetchedAt = now
                )
            )
            mapBundle(forecast, air, now, fromCache = false)
        } catch (networkError: Throwable) {
            if (networkError is CancellationException) throw networkError
            forecastDeferred.cancel()
            airDeferred.cancel()
            val cached = cacheDao.getForLocation(locationKey(latitude, longitude)) ?: throw networkError
            val forecast = gson.fromJson(cached.forecastJson, ForecastResponse::class.java)
            val air = cached.airQualityJson?.let { gson.fromJson(it, AirQualityResponse::class.java) }
            mapBundle(forecast, air, cached.fetchedAt, fromCache = true)
        }
    }

    private fun mapBundle(
        response: ForecastResponse,
        airResponse: AirQualityResponse?,
        fetchedAt: Long,
        fromCache: Boolean
    ): WeatherBundle {
        val currentDto = response.current
        val currentKind = WeatherCodeMapper.toKind(currentDto.weatherCode, currentDto.windSpeed)
        val current = CurrentWeather(
            time = currentDto.time,
            temperature = currentDto.temperature,
            apparentTemperature = currentDto.apparentTemperature,
            humidity = currentDto.humidity,
            precipitation = currentDto.precipitation,
            weatherCode = currentDto.weatherCode,
            cloudCover = currentDto.cloudCover,
            pressure = currentDto.surfacePressure,
            windSpeed = currentDto.windSpeed,
            windDirection = currentDto.windDirection,
            windGust = currentDto.windGusts,
            visibility = currentDto.visibility,
            isDay = currentDto.isDay == 1,
            kind = currentKind
        )

        val startIndex = response.hourly.time.indexOfFirst { it >= currentDto.time }.let { if (it < 0) 0 else it }
        val hourly = (startIndex until minOf(response.hourly.time.size, startIndex + 48)).map { index ->
            val code = response.hourly.weatherCode.valueAt(index, currentDto.weatherCode)
            val wind = response.hourly.windSpeed.valueAt(index, 0.0)
            HourlyForecast(
                time = response.hourly.time.valueAt(index, currentDto.time),
                temperature = response.hourly.temperature.valueAt(index, currentDto.temperature),
                apparentTemperature = response.hourly.apparentTemperature.valueAt(index, currentDto.apparentTemperature),
                precipitationProbability = response.hourly.precipitationProbability.valueAt(index, 0),
                weatherCode = code,
                windSpeed = wind,
                humidity = response.hourly.humidity.valueAt(index, currentDto.humidity),
                uvIndex = response.hourly.uvIndex.valueAt(index, 0.0),
                kind = WeatherCodeMapper.toKind(code, wind)
            )
        }

        val dailyCount = minOf(10, response.daily.time.size)
        val daily = (0 until dailyCount).map { index ->
            val code = response.daily.weatherCode.valueAt(index, currentDto.weatherCode)
            val wind = response.daily.windSpeedMax.valueAt(index, 0.0)
            DailyForecast(
                date = response.daily.time.valueAt(index, currentDto.time.take(10)),
                weatherCode = code,
                temperatureMax = response.daily.temperatureMax.valueAt(index, currentDto.temperature),
                temperatureMin = response.daily.temperatureMin.valueAt(index, currentDto.temperature),
                sunrise = response.daily.sunrise.valueAt(index, ""),
                sunset = response.daily.sunset.valueAt(index, ""),
                precipitationProbabilityMax = response.daily.precipitationProbabilityMax.valueAt(index, 0),
                precipitationSum = response.daily.precipitationSum.valueAt(index, 0.0),
                windSpeedMax = wind,
                uvIndexMax = response.daily.uvIndexMax.valueAt(index, 0.0),
                kind = WeatherCodeMapper.toKind(code, wind)
            )
        }

        val aq = airResponse?.current?.let {
            AirQuality(
                europeanAqi = it.europeanAqi ?: 0,
                pm10 = it.pm10 ?: 0.0,
                pm25 = it.pm25 ?: 0.0,
                carbonMonoxide = it.carbonMonoxide ?: 0.0,
                nitrogenDioxide = it.nitrogenDioxide ?: 0.0,
                ozone = it.ozone ?: 0.0
            )
        }

        return WeatherBundle(
            latitude = response.latitude,
            longitude = response.longitude,
            timezone = response.timezone,
            current = current,
            hourly = hourly,
            daily = daily,
            airQuality = aq,
            fetchedAt = fetchedAt,
            fromCache = fromCache
        )
    }

    private fun locationKey(latitude: Double, longitude: Double): String =
        "${String.format(Locale.US, "%.4f", latitude)},${String.format(Locale.US, "%.4f", longitude)}"

    private fun forecastUrl(latitude: Double, longitude: Double): String {
        val lat = String.format(Locale.US, "%.6f", latitude)
        val lon = String.format(Locale.US, "%.6f", longitude)
        return "https://api.open-meteo.com/v1/forecast" +
            "?latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,cloud_cover,surface_pressure,wind_speed_10m,wind_direction_10m,wind_gusts_10m,visibility,is_day" +
            "&hourly=temperature_2m,apparent_temperature,precipitation_probability,weather_code,wind_speed_10m,relative_humidity_2m,uv_index" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,precipitation_probability_max,precipitation_sum,wind_speed_10m_max,uv_index_max" +
            "&timezone=auto&forecast_days=10"
    }

    private fun airQualityUrl(latitude: Double, longitude: Double): String {
        val lat = String.format(Locale.US, "%.6f", latitude)
        val lon = String.format(Locale.US, "%.6f", longitude)
        return "https://air-quality-api.open-meteo.com/v1/air-quality" +
            "?latitude=$lat&longitude=$lon" +
            "&current=european_aqi,pm10,pm2_5,carbon_monoxide,nitrogen_dioxide,ozone" +
            "&timezone=auto"
    }

    private fun <T> List<T>.valueAt(index: Int, fallback: T): T = getOrNull(index) ?: fallback
}
