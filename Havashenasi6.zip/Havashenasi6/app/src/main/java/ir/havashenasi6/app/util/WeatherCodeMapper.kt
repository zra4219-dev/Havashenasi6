package ir.havashenasi6.app.util

import ir.havashenasi6.app.domain.WeatherKind

object WeatherCodeMapper {
    fun toKind(code: Int, windSpeed: Double = 0.0): WeatherKind {
        if (windSpeed >= 45 && code < 80) return WeatherKind.WINDY
        return when (code) {
            0 -> WeatherKind.SUNNY
            1, 2 -> WeatherKind.MOSTLY_CLEAR
            3 -> WeatherKind.CLOUDY
            45, 48 -> WeatherKind.FOG
            51, 53, 55, 56, 57 -> WeatherKind.DRIZZLE
            61, 63, 66 -> WeatherKind.RAIN
            65, 67, 80, 81, 82 -> WeatherKind.HEAVY_RAIN
            71, 73, 75, 77, 85, 86 -> WeatherKind.SNOW
            95, 96, 99 -> WeatherKind.STORM
            else -> WeatherKind.CLOUDY
        }
    }
}
