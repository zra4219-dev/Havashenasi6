package ir.havashenasi6.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Looper
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.LaunchedEffect
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ir.havashenasi6.app.ui.theme.Havashenasi6Theme

class MainActivity : ComponentActivity() {
    private lateinit var viewModel: MainViewModel

    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result.values.any { it }) fetchDeviceLocation()
        else Toast.makeText(this, "اجازه دسترسی به موقعیت داده نشد.", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as Havashenasi6Application
        viewModel = ViewModelProvider(
            this,
            MainViewModel.Factory(app.weatherRepository, app.settingsRepository)
        )[MainViewModel::class.java]

        setContent {
            val state = viewModel.uiState.collectAsStateWithLifecycle().value
            LaunchedEffect(state.settings.autoLocation) {
                if (state.settings.autoLocation) requestDeviceLocation()
            }
            Havashenasi6Theme(darkTheme = state.settings.darkTheme) {
                Havashenasi6App(
                    viewModel = viewModel,
                    onRequestDeviceLocation = ::requestDeviceLocation
                )
            }
        }
    }

    private fun requestDeviceLocation() {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (fine == PackageManager.PERMISSION_GRANTED || coarse == PackageManager.PERMISSION_GRANTED) {
            fetchDeviceLocation()
        } else {
            locationPermissionLauncher.launch(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            )
        }
    }

    @SuppressLint("MissingPermission")
    private fun fetchDeviceLocation() {
        val manager = getSystemService(LOCATION_SERVICE) as LocationManager
        val provider = when {
            manager.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            else -> null
        }
        if (provider == null) {
            Toast.makeText(this, "موقعیت مکانی دستگاه خاموش است.", Toast.LENGTH_SHORT).show()
            return
        }

        val deliver: (Location?) -> Unit = { location ->
            if (location == null) {
                Toast.makeText(this, "موقعیت فعلی دریافت نشد.", Toast.LENGTH_SHORT).show()
            } else {
                viewModel.saveLocation("موقعیت فعلی", location.latitude.toString(), location.longitude.toString())
                Toast.makeText(this, "موقعیت جدید ذخیره شد.", Toast.LENGTH_SHORT).show()
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            manager.getCurrentLocation(provider, null, mainExecutor) { location -> deliver(location) }
        } else {
            manager.getLastKnownLocation(provider)?.let {
                deliver(it)
                return
            }
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    manager.removeUpdates(this)
                    deliver(location)
                }
            }
            manager.requestSingleUpdate(provider, listener, Looper.getMainLooper())
        }
    }
}
