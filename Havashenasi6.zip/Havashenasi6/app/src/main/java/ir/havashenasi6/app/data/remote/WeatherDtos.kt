package ir.havashenasi6.app.data.remote

import com.google.gson.annotations.SerializedName

data class ForecastResponse(
    val latitude: Double,
    val longitude: Double,
    val timezone: String,
    @SerializedName("utc_offset_seconds") val utcOffsetSeconds: Int,
    val current: CurrentDto,
    val hourly: HourlyDto,
    val daily: DailyDto
)

data class CurrentDto(
    val time: String,
    @SerializedName("temperature_2m") val temperature: Double,
    @SerializedName("relative_humidity_2m") val humidity: Int,
    @SerializedName("apparent_temperature") val apparentTemperature: Double,
    val precipitation: Double,
    @SerializedName("weather_code") val weatherCode: Int,
    @SerializedName("cloud_cover") val cloudCover: Int,
    @SerializedName("surface_pressure") val surfacePressure: Double,
    @SerializedName("wind_speed_10m") val windSpeed: Double,
    @SerializedName("wind_direction_10m") val windDirection: Int,
    @SerializedName("wind_gusts_10m") val windGusts: Double,
    val visibility: Double,
    @SerializedName("is_day") val isDay: Int
)

data class HourlyDto(
    val time: List<String>,
    @SerializedName("temperature_2m") val temperature: List<Double>,
    @SerializedName("apparent_temperature") val apparentTemperature: List<Double>,
    @SerializedName("precipitation_probability") val precipitationProbability: List<Int>,
    @SerializedName("weather_code") val weatherCode: List<Int>,
    @SerializedName("wind_speed_10m") val windSpeed: List<Double>,
    @SerializedName("relative_humidity_2m") val humidity: List<Int>,
    @SerializedName("uv_index") val uvIndex: List<Double>
)

data class DailyDto(
    val time: List<String>,
    @SerializedName("weather_code") val weatherCode: List<Int>,
    @SerializedName("temperature_2m_max") val temperatureMax: List<Double>,
    @SerializedName("temperature_2m_min") val temperatureMin: List<Double>,
    val sunrise: List<String>,
    val sunset: List<String>,
    @SerializedName("precipitation_probability_max") val precipitationProbabilityMax: List<Int>,
    @SerializedName("precipitation_sum") val precipitationSum: List<Double>,
    @SerializedName("wind_speed_10m_max") val windSpeedMax: List<Double>,
    @SerializedName("uv_index_max") val uvIndexMax: List<Double>
)

data class AirQualityResponse(
    val latitude: Double,
    val longitude: Double,
    val current: AirQualityCurrentDto
)

data class AirQualityCurrentDto(
    @SerializedName("european_aqi") val europeanAqi: Int?,
    @SerializedName("pm10") val pm10: Double?,
    @SerializedName("pm2_5") val pm25: Double?,
    @SerializedName("carbon_monoxide") val carbonMonoxide: Double?,
    @SerializedName("nitrogen_dioxide") val nitrogenDioxide: Double?,
    @SerializedName("ozone") val ozone: Double?
)
