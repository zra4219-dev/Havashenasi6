package ir.havashenasi6.app

import android.app.Application
import androidx.room.Room
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.google.gson.Gson
import ir.havashenasi6.app.data.local.AppDatabase
import ir.havashenasi6.app.data.remote.NetworkProvider
import ir.havashenasi6.app.data.repository.SettingsRepository
import ir.havashenasi6.app.data.repository.WeatherRepository
import ir.havashenasi6.app.worker.WeatherRefreshWorker
import java.util.concurrent.TimeUnit

class Havashenasi6Application : Application() {
    lateinit var database: AppDatabase
        private set
    lateinit var weatherRepository: WeatherRepository
        private set
    lateinit var settingsRepository: SettingsRepository
        private set

    override fun onCreate() {
        super.onCreate()
        database = Room.databaseBuilder(this, AppDatabase::class.java, "havashenasi6.db")
            .fallbackToDestructiveMigration()
            .build()
        weatherRepository = WeatherRepository(NetworkProvider.api, database.weatherCacheDao(), Gson())
        settingsRepository = SettingsRepository(this)
        schedulePeriodicRefresh()
    }

    private fun schedulePeriodicRefresh() {
        val request = PeriodicWorkRequestBuilder<WeatherRefreshWorker>(3, TimeUnit.HOURS)
            .setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build()
            )
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "weather_periodic_refresh",
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }
}
