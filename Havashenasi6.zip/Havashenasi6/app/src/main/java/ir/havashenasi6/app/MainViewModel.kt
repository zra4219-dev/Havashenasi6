package ir.havashenasi6.app

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ir.havashenasi6.app.data.repository.SettingsRepository
import ir.havashenasi6.app.data.repository.WeatherRepository
import ir.havashenasi6.app.domain.AppSettings
import ir.havashenasi6.app.domain.WeatherBundle
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class MainUiState(
    val settings: AppSettings = AppSettings(),
    val weather: WeatherBundle? = null,
    val isLoading: Boolean = true,
    val isRefreshing: Boolean = false,
    val errorMessage: String? = null
)

class MainViewModel(
    private val weatherRepository: WeatherRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {
    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            settingsRepository.settings.collectLatest { settings ->
                val locationChanged = settings.latitude != _uiState.value.settings.latitude ||
                    settings.longitude != _uiState.value.settings.longitude
                _uiState.update { it.copy(settings = settings) }
                if (_uiState.value.weather == null || locationChanged) refresh()
            }
        }
    }

    fun refresh() {
        viewModelScope.launch {
            val hasData = _uiState.value.weather != null
            _uiState.update {
                it.copy(
                    isLoading = !hasData,
                    isRefreshing = hasData,
                    errorMessage = null
                )
            }
            val settings = settingsRepository.settings.first()
            try {
                val bundle = weatherRepository.loadWeather(settings.latitude, settings.longitude)
                _uiState.update {
                    it.copy(weather = bundle, isLoading = false, isRefreshing = false, errorMessage = null)
                }
            } catch (error: CancellationException) {
                throw error
            } catch (error: Throwable) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        isRefreshing = false,
                        errorMessage = error.message ?: "دریافت اطلاعات هواشناسی ناموفق بود."
                    )
                }
            }
        }
    }

    fun saveLocation(name: String, latitudeText: String, longitudeText: String) {
        val latitude = latitudeText.toAsciiNumber().toDoubleOrNull()
        val longitude = longitudeText.toAsciiNumber().toDoubleOrNull()
        if (latitude == null || longitude == null || latitude !in -90.0..90.0 || longitude !in -180.0..180.0) {
            _uiState.update { it.copy(errorMessage = "مختصات واردشده معتبر نیست.") }
            return
        }
        viewModelScope.launch { settingsRepository.saveLocation(name, latitude, longitude) }
    }

    fun setAutoLocation(enabled: Boolean) = viewModelScope.launch { settingsRepository.setAutoLocation(enabled) }
    fun setUseFahrenheit(enabled: Boolean) = viewModelScope.launch { settingsRepository.setUseFahrenheit(enabled) }
    fun setUseMiles(enabled: Boolean) = viewModelScope.launch { settingsRepository.setUseMiles(enabled) }
    fun setDarkTheme(enabled: Boolean) = viewModelScope.launch { settingsRepository.setDarkTheme(enabled) }

    private fun String.toAsciiNumber(): String = buildString(length) {
        this@toAsciiNumber.forEach { ch ->
            append(
                when (ch) {
                    '۰', '٠' -> '0'; '۱', '١' -> '1'; '۲', '٢' -> '2'; '۳', '٣' -> '3'
                    '۴', '٤' -> '4'; '۵', '٥' -> '5'; '۶', '٦' -> '6'; '۷', '٧' -> '7'
                    '۸', '٨' -> '8'; '۹', '٩' -> '9'; '٫', ',' -> '.'
                    else -> ch
                }
            )
        }
    }.trim()

    class Factory(
        private val weatherRepository: WeatherRepository,
        private val settingsRepository: SettingsRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return MainViewModel(weatherRepository, settingsRepository) as T
        }
    }
}
