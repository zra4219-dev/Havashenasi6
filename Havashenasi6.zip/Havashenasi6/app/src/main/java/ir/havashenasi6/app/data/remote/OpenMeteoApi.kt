package ir.havashenasi6.app.data.remote

import retrofit2.http.GET
import retrofit2.http.Url

interface OpenMeteoApi {
    @GET
    suspend fun getForecast(@Url url: String): ForecastResponse

    @GET
    suspend fun getAirQuality(@Url url: String): AirQualityResponse
}
