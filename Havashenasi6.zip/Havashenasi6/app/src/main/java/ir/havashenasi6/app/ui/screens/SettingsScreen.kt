package ir.havashenasi6.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import ir.havashenasi6.app.MainUiState
import ir.havashenasi6.app.ui.components.GlassCard
import ir.havashenasi6.app.ui.components.LiveWeatherBackground

@Composable
fun SettingsScreen(
    state: MainUiState,
    onSaveLocation: (String, String, String) -> Unit,
    onAutoLocationChanged: (Boolean) -> Unit,
    onRequestDeviceLocation: () -> Unit,
    onFahrenheitChanged: (Boolean) -> Unit,
    onMilesChanged: (Boolean) -> Unit,
    onDarkThemeChanged: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    var name by remember { mutableStateOf(state.settings.locationName) }
    var latitude by remember { mutableStateOf(state.settings.latitude.toString()) }
    var longitude by remember { mutableStateOf(state.settings.longitude.toString()) }

    LaunchedEffect(state.settings.locationName, state.settings.latitude, state.settings.longitude) {
        name = state.settings.locationName
        latitude = state.settings.latitude.toString()
        longitude = state.settings.longitude.toString()
    }

    val weather = state.weather
    LiveWeatherBackground(
        kind = weather?.current?.kind ?: ir.havashenasi6.app.domain.WeatherKind.MOSTLY_CLEAR,
        isDay = weather?.current?.isDay ?: false,
        modifier = modifier.fillMaxSize()
    ) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("تنظیمات", style = MaterialTheme.typography.headlineLarge, color = Color.White)

            GlassCard(Modifier.fillMaxWidth()) {
                Text("موقعیت اصلی", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("نام شهر یا موقعیت") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = latitude,
                    onValueChange = { latitude = it },
                    label = { Text("عرض جغرافیایی") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = longitude,
                    onValueChange = { longitude = it },
                    label = { Text("طول جغرافیایی") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { onSaveLocation(name, latitude, longitude) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Rounded.Save, null)
                        Text(" ذخیره")
                    }
                    Button(
                        onClick = onRequestDeviceLocation,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Rounded.MyLocation, null)
                        Text(" موقعیت من")
                    }
                }
                Spacer(Modifier.height(8.dp))
                SettingSwitch(
                    title = "موقعیت خودکار",
                    subtitle = "در شروع‌های بعدی، موقعیت زنده دستگاه مبنا قرار گیرد.",
                    checked = state.settings.autoLocation,
                    onCheckedChange = onAutoLocationChanged
                )
            }

            GlassCard(Modifier.fillMaxWidth()) {
                Text("واحدها و ظاهر", style = MaterialTheme.typography.titleLarge)
                SettingSwitch("فارنهایت", "دما به‌جای سلسیوس با °F نمایش داده شود.", state.settings.useFahrenheit, onFahrenheitChanged)
                SettingSwitch("مایل", "سرعت باد با مایل بر ساعت نمایش داده شود.", state.settings.useMiles, onMilesChanged)
                SettingSwitch("تم تیره", "رابط تیره برای شب و مصرف کمتر نمایشگر OLED.", state.settings.darkTheme, onDarkThemeChanged)
            }

            GlassCard(Modifier.fillMaxWidth()) {
                Text("درباره هواشناسی ۶", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                Text("نسخه ۱.۰.۰ آزمایشی", color = Color.White.copy(.82f))
                Text("داده‌های پیش‌بینی و کیفیت هوا از Open‑Meteo دریافت می‌شوند. انیمیشن‌ها کاملاً با Jetpack Compose رسم شده‌اند.", color = Color.White.copy(.76f))
            }

            state.errorMessage?.let { Text(it, color = Color(0xFFFFD0C8)) }
            Spacer(Modifier.height(90.dp))
        }
    }
}

@Composable
private fun SettingSwitch(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(.62f))
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
