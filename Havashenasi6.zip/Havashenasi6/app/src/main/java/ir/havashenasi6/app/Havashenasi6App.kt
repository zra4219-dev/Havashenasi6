package ir.havashenasi6.app

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Air
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Timeline
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import ir.havashenasi6.app.domain.WeatherKind
import ir.havashenasi6.app.ui.components.LiveWeatherBackground
import ir.havashenasi6.app.ui.screens.AirQualityScreen
import ir.havashenasi6.app.ui.screens.ForecastScreen
import ir.havashenasi6.app.ui.screens.HomeScreen
import ir.havashenasi6.app.ui.screens.SettingsScreen
import ir.havashenasi6.app.ui.screens.SplashScreen

private sealed class Destination(
    val route: String,
    val title: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    data object Home : Destination("home", "خانه", Icons.Rounded.Cloud)
    data object Forecast : Destination("forecast", "پیش‌بینی", Icons.Rounded.Timeline)
    data object Air : Destination("air", "آلودگی", Icons.Rounded.Air)
    data object Settings : Destination("settings", "تنظیمات", Icons.Rounded.Settings)
}

@Composable
fun Havashenasi6App(
    viewModel: MainViewModel,
    onRequestDeviceLocation: () -> Unit
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var showSplash by rememberSaveable { mutableStateOf(true) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        if (showSplash) {
            LiveWeatherBackground(
                kind = state.weather?.current?.kind ?: WeatherKind.MOSTLY_CLEAR,
                isDay = state.weather?.current?.isDay ?: true,
                modifier = Modifier.fillMaxSize()
            ) {
                SplashScreen(onFinished = { showSplash = false })
            }
        } else {
            MainNavigation(
                state = state,
                viewModel = viewModel,
                onRequestDeviceLocation = onRequestDeviceLocation
            )
        }
    }
}

@Composable
private fun MainNavigation(
    state: MainUiState,
    viewModel: MainViewModel,
    onRequestDeviceLocation: () -> Unit
) {
    val navController = rememberNavController()
    val destinations = listOf(
        Destination.Home,
        Destination.Forecast,
        Destination.Air,
        Destination.Settings
    )
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route

    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xE60B1A27),
                tonalElevation = 0.dp
            ) {
                destinations.forEach { destination ->
                    NavigationBarItem(
                        selected = currentRoute == destination.route,
                        onClick = {
                            navController.navigate(destination.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(destination.icon, contentDescription = null) },
                        label = { Text(destination.title) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Destination.Home.route,
            modifier = Modifier.padding(bottom = padding.calculateBottomPadding())
        ) {
            composable(Destination.Home.route) {
                HomeScreen(state = state, onRefresh = viewModel::refresh)
            }
            composable(Destination.Forecast.route) {
                ForecastScreen(state = state)
            }
            composable(Destination.Air.route) {
                AirQualityScreen(state = state)
            }
            composable(Destination.Settings.route) {
                SettingsScreen(
                    state = state,
                    onSaveLocation = viewModel::saveLocation,
                    onAutoLocationChanged = viewModel::setAutoLocation,
                    onRequestDeviceLocation = onRequestDeviceLocation,
                    onFahrenheitChanged = viewModel::setUseFahrenheit,
                    onMilesChanged = viewModel::setUseMiles,
                    onDarkThemeChanged = viewModel::setDarkTheme
                )
            }
        }
    }
}
