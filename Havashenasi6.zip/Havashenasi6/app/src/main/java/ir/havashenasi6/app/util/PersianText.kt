package ir.havashenasi6.app.util

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.floor

fun String.toPersianDigits(): String = buildString(length) {
    this@toPersianDigits.forEach { ch ->
        append(
            when (ch) {
                '0' -> '۰'; '1' -> '۱'; '2' -> '۲'; '3' -> '۳'; '4' -> '۴'
                '5' -> '۵'; '6' -> '۶'; '7' -> '۷'; '8' -> '۸'; '9' -> '۹'
                else -> ch
            }
        )
    }
}

fun Double.oneDecimalFa(): String = String.format(Locale.US, "%.1f", this).toPersianDigits()
fun Double.roundFa(): String = String.format(Locale.US, "%.0f", this).toPersianDigits()
fun Int.fa(): String = toString().toPersianDigits()

object PersianDateFormatter {
    private val weekDays = listOf("دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه", "یکشنبه")
    private val months = listOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )

    fun dateLabel(isoDate: String, includeWeekDay: Boolean = true): String = runCatching {
        val date = LocalDate.parse(isoDate.take(10))
        val jalali = gregorianToJalali(date.year, date.monthValue, date.dayOfMonth)
        val day = weekDays[date.dayOfWeek.value - 1]
        val core = "${jalali.third.fa()} ${months[jalali.second - 1]} ${jalali.first.fa()}"
        if (includeWeekDay) "$day، $core" else core
    }.getOrElse { isoDate.toPersianDigits() }

    fun shortDate(isoDate: String): String = runCatching {
        val date = LocalDate.parse(isoDate.take(10))
        val j = gregorianToJalali(date.year, date.monthValue, date.dayOfMonth)
        "${j.second.fa()}/${j.third.fa()}"
    }.getOrElse { isoDate.take(10).toPersianDigits() }

    fun hour(isoDateTime: String): String = runCatching {
        val dt = LocalDateTime.parse(isoDateTime, DateTimeFormatter.ISO_LOCAL_DATE_TIME)
        "%02d:00".format(Locale.US, dt.hour).toPersianDigits()
    }.getOrElse { isoDateTime.takeLast(5).toPersianDigits() }

    private fun gregorianToJalali(gyInput: Int, gmInput: Int, gdInput: Int): Triple<Int, Int, Int> {
        val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        var gy = if (gyInput > 1600) gyInput - 1600 else gyInput - 621
        val gy2 = if (gmInput > 2) gy + 1 else gy
        var days = 365 * gy + floor((gy2 + 3) / 4.0).toInt() - floor((gy2 + 99) / 100.0).toInt() +
            floor((gy2 + 399) / 400.0).toInt() - 80 + gdInput + gdm[gmInput - 1]
        var jy = 979 + 33 * floor(days / 12053.0).toInt()
        days %= 12053
        jy += 4 * floor(days / 1461.0).toInt()
        days %= 1461
        if (days > 365) {
            jy += floor((days - 1) / 365.0).toInt()
            days = (days - 1) % 365
        }
        val jm: Int
        val jd: Int
        if (days < 186) {
            jm = 1 + floor(days / 31.0).toInt()
            jd = 1 + days % 31
        } else {
            jm = 7 + floor((days - 186) / 30.0).toInt()
            jd = 1 + (days - 186) % 30
        }
        return Triple(jy, jm, jd)
    }
}
