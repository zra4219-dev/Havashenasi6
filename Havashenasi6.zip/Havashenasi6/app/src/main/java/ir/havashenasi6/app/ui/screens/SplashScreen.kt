package ir.havashenasi6.app.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SplashScreen(onFinished: () -> Unit) {
    val scale = remember { Animatable(.72f) }
    val alpha = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        coroutineScope {
            launch { scale.animateTo(1f, tween(700, easing = FastOutSlowInEasing)) }
            launch { alpha.animateTo(1f, tween(500)) }
        }
        delay(650)
        onFinished()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .alpha(alpha.value)
            .scale(scale.value),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        WeatherSixLogo(Modifier.size(150.dp))
        Text(
            text = "هواشناسی ۶",
            color = Color.White,
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.ExtraBold
        )
        Text(
            text = "هوای امروز، روشن‌تر از همیشه",
            color = Color.White.copy(alpha = .76f),
            fontSize = 14.sp
        )
    }
}

@Composable
private fun WeatherSixLogo(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val s = size.minDimension
        drawCircle(
            brush = Brush.radialGradient(
                listOf(Color(0xFFFFE07A), Color(0xFFFFB747)),
                center = Offset(s * .34f, s * .31f),
                radius = s * .24f
            ),
            radius = s * .18f,
            center = Offset(s * .34f, s * .31f)
        )
        repeat(10) { index ->
            val angle = Math.toRadians((index * 36).toDouble())
            val center = Offset(s * .34f, s * .31f)
            val from = Offset(
                center.x + kotlin.math.cos(angle).toFloat() * s * .24f,
                center.y + kotlin.math.sin(angle).toFloat() * s * .24f
            )
            val to = Offset(
                center.x + kotlin.math.cos(angle).toFloat() * s * .30f,
                center.y + kotlin.math.sin(angle).toFloat() * s * .30f
            )
            drawLine(Color(0xFFFFD05E), from, to, s * .025f, cap = StrokeCap.Round)
        }

        val cloud = Color.White.copy(alpha = .96f)
        drawCircle(cloud, s * .17f, Offset(s * .37f, s * .55f))
        drawCircle(cloud, s * .23f, Offset(s * .55f, s * .49f))
        drawCircle(cloud, s * .16f, Offset(s * .72f, s * .57f))
        drawRoundRect(
            color = cloud,
            topLeft = Offset(s * .22f, s * .54f),
            size = Size(s * .66f, s * .25f)
        )

        val rain = Color(0xFF84DFFF)
        listOf(.37f, .55f, .73f).forEach { x ->
            drawLine(
                rain,
                Offset(s * x, s * .78f),
                Offset(s * (x - .035f), s * .91f),
                s * .035f,
                cap = StrokeCap.Round
            )
        }
    }
}
