package ir.havashenasi6.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF86D4FF),
    onPrimary = Color(0xFF00344E),
    secondary = Color(0xFFFFD166),
    background = Color(0xFF07131F),
    surface = Color(0xFF102536),
    onSurface = Color.White,
    onBackground = Color.White
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF00639A),
    secondary = Color(0xFF755B00),
    background = Color(0xFFEAF6FF),
    surface = Color.White,
    onSurface = Color(0xFF10202C),
    onBackground = Color(0xFF10202C)
)

@Composable
fun Havashenasi6Theme(
    darkTheme: Boolean,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        content = content
    )
}
