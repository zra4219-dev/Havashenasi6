package ir.havashenasi6.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ir.havashenasi6.app.MainUiState
import ir.havashenasi6.app.ui.components.GlassCard
import ir.havashenasi6.app.ui.components.LiveWeatherBackground
import ir.havashenasi6.app.ui.components.WeatherIcon
import ir.havashenasi6.app.util.PersianDateFormatter
import ir.havashenasi6.app.util.fa
import ir.havashenasi6.app.util.oneDecimalFa

@Composable
fun ForecastScreen(state: MainUiState, modifier: Modifier = Modifier) {
    val weather = state.weather
    LiveWeatherBackground(
        kind = weather?.current?.kind ?: ir.havashenasi6.app.domain.WeatherKind.CLOUDY,
        isDay = weather?.current?.isDay ?: true,
        modifier = modifier.fillMaxSize()
    ) {
        if (weather == null) return@LiveWeatherBackground
        Column(
            Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("پیش‌بینی دقیق", style = MaterialTheme.typography.headlineLarge, color = Color.White)
            Text(state.settings.locationName, color = Color.White.copy(.8f))

            GlassCard(Modifier.fillMaxWidth()) {
                Text("نمودار دمای ۲۴ ساعت آینده", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(14.dp))
                TemperatureChart(
                    values = weather.hourly.take(24).map { if (state.settings.useFahrenheit) it.temperature * 9 / 5 + 32 else it.temperature },
                    modifier = Modifier.fillMaxWidth().height(150.dp)
                )
                Spacer(Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(weather.hourly.take(24).filterIndexed { index, _ -> index % 3 == 0 }) { item ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(66.dp)) {
                            Text(PersianDateFormatter.hour(item.time), color = Color.White.copy(.75f))
                            WeatherIcon(item.kind, Modifier.size(40.dp).padding(4.dp))
                            Text(temperatureText(item.temperature, state.settings), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            GlassCard(Modifier.fillMaxWidth()) {
                Text("پیش‌بینی روزانه", style = MaterialTheme.typography.titleLarge)
                weather.daily.forEachIndexed { index, day ->
                    if (index > 0) HorizontalDivider(color = Color.White.copy(.12f))
                    Column(Modifier.fillMaxWidth().padding(vertical = 12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(PersianDateFormatter.dateLabel(day.date), fontWeight = FontWeight.Bold)
                                Text(day.kind.faTitle, color = Color.White.copy(.72f))
                            }
                            WeatherIcon(day.kind, Modifier.size(54.dp).padding(5.dp))
                            Text("${temperatureText(day.temperatureMax, state.settings)} / ${temperatureText(day.temperatureMin, state.settings)}", fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(7.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("بارش ${day.precipitationProbabilityMax.fa()}٪", style = MaterialTheme.typography.bodyMedium)
                            Text("باد ${windText(day.windSpeedMax, state.settings)}", style = MaterialTheme.typography.bodyMedium)
                            Text("UV ${day.uvIndexMax.oneDecimalFa()}", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
            Spacer(Modifier.height(90.dp))
        }
    }
}

@Composable
private fun TemperatureChart(values: List<Double>, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        if (values.size < 2) return@Canvas
        val min = values.minOrNull() ?: return@Canvas
        val max = values.maxOrNull() ?: return@Canvas
        val range = (max - min).takeIf { it > .1 } ?: 1.0
        val horizontal = size.width / (values.size - 1)
        val path = Path()
        values.forEachIndexed { index, value ->
            val x = index * horizontal
            val normalized = ((value - min) / range).toFloat()
            val y = size.height * (.86f - normalized * .68f)
            if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
            drawCircle(Color.White, 4.5f, Offset(x, y))
        }
        repeat(4) { i ->
            val y = size.height * (.18f + i * .22f)
            drawLine(Color.White.copy(.10f), Offset(0f, y), Offset(size.width, y), 1f)
        }
        drawPath(path, Color(0xFFFFE07A), style = Stroke(5f, cap = StrokeCap.Round))
    }
}
