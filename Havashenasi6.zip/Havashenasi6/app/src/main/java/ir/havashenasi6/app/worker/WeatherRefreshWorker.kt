package ir.havashenasi6.app.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import ir.havashenasi6.app.Havashenasi6Application
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.first

class WeatherRefreshWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext as Havashenasi6Application
        val settings = app.settingsRepository.settings.first()
        return try {
            app.weatherRepository.loadWeather(settings.latitude, settings.longitude)
            Result.success()
        } catch (error: CancellationException) {
            throw error
        } catch (_: Throwable) {
            Result.retry()
        }
    }
}
