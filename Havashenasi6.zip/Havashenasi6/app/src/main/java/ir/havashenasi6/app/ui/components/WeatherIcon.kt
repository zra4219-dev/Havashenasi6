package ir.havashenasi6.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import ir.havashenasi6.app.domain.WeatherKind

@Composable
fun WeatherIcon(kind: WeatherKind, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val s = size.minDimension
        val sun = Color(0xFFFFD45C)
        val cloud = Color.White.copy(alpha = 0.92f)
        val rain = Color(0xFF8BE0FF)

        if (kind == WeatherKind.SUNNY || kind == WeatherKind.MOSTLY_CLEAR) {
            drawCircle(sun, radius = s * 0.22f, center = Offset(s * 0.38f, s * 0.36f))
            repeat(8) { i ->
                val angle = Math.toRadians((i * 45).toDouble())
                val c = Offset(s * 0.38f, s * 0.36f)
                val a = Offset(c.x + kotlin.math.cos(angle).toFloat() * s * 0.30f, c.y + kotlin.math.sin(angle).toFloat() * s * 0.30f)
                val b = Offset(c.x + kotlin.math.cos(angle).toFloat() * s * 0.38f, c.y + kotlin.math.sin(angle).toFloat() * s * 0.38f)
                drawLine(sun, a, b, strokeWidth = s * 0.045f, cap = StrokeCap.Round)
            }
        }

        if (kind != WeatherKind.SUNNY) {
            drawCircle(cloud, radius = s * 0.22f, center = Offset(s * 0.43f, s * 0.50f))
            drawCircle(cloud, radius = s * 0.28f, center = Offset(s * 0.62f, s * 0.45f))
            drawRoundRect(cloud, topLeft = Offset(s * 0.25f, s * 0.48f), size = Size(s * 0.62f, s * 0.28f))
        }

        when (kind) {
            WeatherKind.RAIN, WeatherKind.HEAVY_RAIN, WeatherKind.DRIZZLE, WeatherKind.STORM -> {
                listOf(0.38f, 0.57f, 0.76f).forEach { x ->
                    drawLine(rain, Offset(s * x, s * 0.78f), Offset(s * (x - 0.04f), s * 0.93f), strokeWidth = s * 0.045f, cap = StrokeCap.Round)
                }
            }
            WeatherKind.SNOW -> {
                listOf(0.38f, 0.57f, 0.76f).forEach { x ->
                    drawCircle(Color.White, radius = s * 0.045f, center = Offset(s * x, s * 0.86f))
                }
            }
            WeatherKind.FOG -> {
                repeat(3) { i ->
                    drawLine(Color.White.copy(alpha = .7f), Offset(s * .25f, s * (.76f + i * .09f)), Offset(s * .86f, s * (.76f + i * .09f)), strokeWidth = s * .035f, cap = StrokeCap.Round)
                }
            }
            WeatherKind.WINDY -> {
                repeat(3) { i ->
                    drawArc(Color.White, -20f, 190f, false, Offset(s * .25f, s * (.67f + i * .08f)), Size(s * .55f, s * .16f), style = Stroke(s * .035f, cap = StrokeCap.Round))
                }
            }
            else -> Unit
        }
    }
}
