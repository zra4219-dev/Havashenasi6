package ir.havashenasi6.app.domain

enum class WeatherKind(val faTitle: String) {
    SUNNY("آفتابی"),
    MOSTLY_CLEAR("صاف تا کمی ابری"),
    CLOUDY("ابری"),
    FOG("مه‌آلود"),
    DRIZZLE("نم‌نم باران"),
    RAIN("بارانی"),
    HEAVY_RAIN("باران شدید"),
    SNOW("برفی"),
    STORM("رعدوبرق"),
    WINDY("وزش باد")
}

data class CurrentWeather(
    val time: String,
    val temperature: Double,
    val apparentTemperature: Double,
    val humidity: Int,
    val precipitation: Double,
    val weatherCode: Int,
    val cloudCover: Int,
    val pressure: Double,
    val windSpeed: Double,
    val windDirection: Int,
    val windGust: Double,
    val visibility: Double,
    val isDay: Boolean,
    val kind: WeatherKind
)

data class HourlyForecast(
    val time: String,
    val temperature: Double,
    val apparentTemperature: Double,
    val precipitationProbability: Int,
    val weatherCode: Int,
    val windSpeed: Double,
    val humidity: Int,
    val uvIndex: Double,
    val kind: WeatherKind
)

data class DailyForecast(
    val date: String,
    val weatherCode: Int,
    val temperatureMax: Double,
    val temperatureMin: Double,
    val sunrise: String,
    val sunset: String,
    val precipitationProbabilityMax: Int,
    val precipitationSum: Double,
    val windSpeedMax: Double,
    val uvIndexMax: Double,
    val kind: WeatherKind
)

data class AirQuality(
    val europeanAqi: Int,
    val pm10: Double,
    val pm25: Double,
    val carbonMonoxide: Double,
    val nitrogenDioxide: Double,
    val ozone: Double
)

data class WeatherBundle(
    val latitude: Double,
    val longitude: Double,
    val timezone: String,
    val current: CurrentWeather,
    val hourly: List<HourlyForecast>,
    val daily: List<DailyForecast>,
    val airQuality: AirQuality?,
    val fetchedAt: Long,
    val fromCache: Boolean
)

data class AppSettings(
    val locationName: String = "موقعیت اصلی",
    val latitude: Double = 37.189189,
    val longitude: Double = 55.548342,
    val autoLocation: Boolean = false,
    val useFahrenheit: Boolean = false,
    val useMiles: Boolean = false,
    val darkTheme: Boolean = true
)
