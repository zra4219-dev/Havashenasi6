package ir.havashenasi6.app.util

import ir.havashenasi6.app.domain.WeatherKind
import org.junit.Assert.assertEquals
import org.junit.Test

class WeatherCodeMapperTest {
    @Test
    fun mapsMajorWmoCodes() {
        assertEquals(WeatherKind.SUNNY, WeatherCodeMapper.toKind(0))
        assertEquals(WeatherKind.FOG, WeatherCodeMapper.toKind(45))
        assertEquals(WeatherKind.RAIN, WeatherCodeMapper.toKind(61))
        assertEquals(WeatherKind.HEAVY_RAIN, WeatherCodeMapper.toKind(82))
        assertEquals(WeatherKind.SNOW, WeatherCodeMapper.toKind(75))
        assertEquals(WeatherKind.STORM, WeatherCodeMapper.toKind(95))
    }

    @Test
    fun strongWindOverridesNonConvectiveWeather() {
        assertEquals(WeatherKind.WINDY, WeatherCodeMapper.toKind(code = 3, windSpeed = 50.0))
    }
}
