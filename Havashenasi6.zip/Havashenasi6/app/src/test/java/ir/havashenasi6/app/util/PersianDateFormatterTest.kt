package ir.havashenasi6.app.util

import org.junit.Assert.assertTrue
import org.junit.Test

class PersianDateFormatterTest {
    @Test
    fun convertsNowruzToJalali() {
        val label = PersianDateFormatter.dateLabel("2025-03-21T12:00")
        assertTrue(label.contains("۱ فروردین ۱۴۰۴"))
    }

    @Test
    fun convertsPersianDigits() {
        assertTrue("2026".toPersianDigits() == "۲۰۲۶")
    }
}
