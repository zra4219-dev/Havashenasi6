# Retrofit/Gson models are retained explicitly for release builds.
-keepattributes Signature
-keepattributes *Annotation*
-keep class ir.havashenasi6.app.data.remote.** { *; }
